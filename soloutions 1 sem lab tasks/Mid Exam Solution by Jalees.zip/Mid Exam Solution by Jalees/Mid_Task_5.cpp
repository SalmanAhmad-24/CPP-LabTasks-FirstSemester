#include<iostream>
using namespace std;
int main()
{
    int x, n, check = 0, curr;
    float sum = 0;
    do
    {
        cout<<"Enter value of x: ";
        cin>>x;
        cout<<"Enter value of n: ";
        cin>>n;
        if (n%2 == 0)
        {
            for (int n_ctr = 2; n_ctr <= n; n_ctr+=2)
            {
                float power = 1, fact = 1;
                curr = x - n_ctr;
                for (int p_ctr = 1; p_ctr <= n_ctr; p_ctr++)
                {
                    power = power * curr;
                }
                cout<<"Power: "<<power<<endl;
                for (int f_ctr = curr; f_ctr >= 1; f_ctr--)
                {
                    fact = fact * f_ctr;
                }
                cout<<"Fact: "<<fact<<endl;
                sum = sum + (power/fact);
                check = 0;
            }
            cout<<"The sum of the given equeation is : "<<sum;
        }
        else
        {
            cout<<"You have entered invalid enteries. Please enter correct information!"<<endl;
            check = 1;
        }
    } while (check == 1);
}
