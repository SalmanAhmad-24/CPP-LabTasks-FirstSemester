#include<iostream>
using namespace std;
int main()
{
    float num;
    cout<<"Enter a number: ";
    cin>>num;
    float temp = num;
    while (num != int(num))
    {
        num = num*10;
    }
    cout<<"The last two digits of "<<temp<<" are "<<(int(num)%100);
}
