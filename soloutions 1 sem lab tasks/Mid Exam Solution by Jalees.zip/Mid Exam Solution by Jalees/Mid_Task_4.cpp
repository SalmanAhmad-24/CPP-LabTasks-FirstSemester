#include<iostream>
using namespace std;
int main()
{
    char choice;
    do
	{
        int num1, num2, hcf, min;
        cout<<"Enter first number: ";
        cin>>num1;
        cout<<"Enter second number: ";
        cin>>num2;
        if (num1 > num2)
        {
        	min = num2;
		}
		else
		{
			min = num1;
		}
        for(int ctr = 1; ctr <= min; ctr++)
		{
            if(num1%ctr == 0 && num2%ctr == 0)
			{
                hcf = ctr;
            }
        }
		cout<<"The HCF of the numbers is: "<<hcf<<endl;
        cout<<"Do you want to calculate again? (Y/N): ";
        cin>>choice;
    } while(choice=='Y');
}
