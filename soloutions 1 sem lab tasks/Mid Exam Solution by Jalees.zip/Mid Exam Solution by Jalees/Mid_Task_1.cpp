#include<iostream>
using namespace std;
int main()
{
    int lower, upper;
    cout<<"Enter lower limit of a range: ";
    cin>>lower;
    cout<<"Enter upper limit of a range: ";
    cin>>upper;
    cout<<"Even numbers between "<<lower<<" and "<<upper<<" that are divisible by 3 are:";
    for (lower; lower <= upper; lower++)
    {
        if (lower%2 == 0 && lower%3 == 0)
        {
            cout<<lower<<", ";
        }
    }
}